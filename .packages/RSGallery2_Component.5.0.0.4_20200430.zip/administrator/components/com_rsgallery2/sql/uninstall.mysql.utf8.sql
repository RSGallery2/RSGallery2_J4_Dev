#
# uninstall sql for RSGallery2
#

#DROP TABLE IF EXISTS `#__rsg2_galleries`;
#DROP TABLE IF EXISTS `#__rsg2_images`;
#DROP TABLE IF EXISTS `#__rsg2_comments`;
#DROP TABLE IF EXISTS `#__rsg2_acl`;

#
# uninstall sql for RSGallery2 J! Version 1.5/2.5/3.x
#

#DROP TABLE IF EXISTS `#__rsgallery2_acl`;
#DROP TABLE IF EXISTS `#__rsgallery2_comments`;
#DROP TABLE IF EXISTS `#__rsgallery2_config`;
#DROP TABLE IF EXISTS `#__rsgallery2_files`;
#DROP TABLE IF EXISTS `#__rsgallery2_galleries`;

