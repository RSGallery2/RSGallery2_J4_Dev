<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_rsgallery2
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Rsgallery2\Administrator\Service\HTML;

defined('JPATH_BASE') or die;

/**
 * Rsgallery2 HTML class.
 *
 * @since  1.0
 */
class AdministratorService
{
}
