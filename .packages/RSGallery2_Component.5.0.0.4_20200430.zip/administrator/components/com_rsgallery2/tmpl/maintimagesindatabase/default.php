<?php
echo 'default.php: ' . realpath(dirname(__FILE__));
?>


